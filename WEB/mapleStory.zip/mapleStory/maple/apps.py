from django.apps import AppConfig


class MapleConfig(AppConfig):
    name = 'maple'
