from django.apps import AppConfig


class MapleappConfig(AppConfig):
    name = 'mapleApp'
